export const em = {
  EMAIL: "rodgersmanyeve@gmail.com",
  PASSWORD: "ihhcqhdfrajeluct",
};
